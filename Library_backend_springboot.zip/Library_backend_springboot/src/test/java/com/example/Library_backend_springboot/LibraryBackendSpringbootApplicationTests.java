package com.example.Library_backend_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryBackendSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
